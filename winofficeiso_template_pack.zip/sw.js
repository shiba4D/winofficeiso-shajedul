<!-- Service worker for caching and offline access -->
